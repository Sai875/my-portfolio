/* =====================================================================
   contact.js: small helpers for the contact form.
   1. Shows friendly error messages under each field.
   2. Stops an accidental double click from sending the message twice.
   The form itself is sent by the browser straight to Netlify;
   this file only improves the experience.
   ===================================================================== */
(function () {
  'use strict';

  var form = document.getElementById('contact-form');
  if (!form) return;

  var button = form.querySelector('.cf__button');
  var buttonLabel = button.querySelector('.cf__button-label');
  var defaultLabel = buttonLabel.textContent;

  // Friendly messages, keyed by field name and problem type.
  var messages = {
    name:    { valueMissing: 'Please enter your name.' },
    email:   {
      valueMissing: 'Please enter your email address.',
      typeMismatch: 'That doesn’t look like an email address. Try name@example.com.'
    },
    message: { valueMissing: 'Please write a short message.' }
  };

  function errorBox(field) {
    return document.getElementById(field.id + '-error');
  }

  function showError(field) {
    var text = '';
    var rules = messages[field.name] || {};
    for (var problem in rules) {
      if (field.validity[problem]) { text = rules[problem]; break; }
    }
    errorBox(field).textContent = text || field.validationMessage;
    field.setAttribute('aria-invalid', 'true');
  }

  function clearError(field) {
    errorBox(field).textContent = '';
    field.removeAttribute('aria-invalid');
  }

  var fields = form.querySelectorAll('input[required], textarea[required]');

  Array.prototype.forEach.call(fields, function (field) {
    // Runs when the visitor presses Send and this field is not valid.
    field.addEventListener('invalid', function (event) {
      event.preventDefault(); // use our message instead of the browser's pop-up
      showError(field);
      if (form.querySelector(':invalid') === field) field.focus();
    });

    // Clear the message as soon as the field becomes valid.
    field.addEventListener('input', function () {
      if (field.validity.valid) clearError(field);
    });

    // Check a half-filled field when the visitor leaves it.
    field.addEventListener('blur', function () {
      if (field.value && !field.validity.valid) showError(field);
    });
  });

  // Double-click protection. This only runs once the form is valid.
  form.addEventListener('submit', function () {
    setTimeout(function () {
      button.disabled = true;
      buttonLabel.textContent = 'Sending…';
    }, 0);
  });

  // If the visitor presses Back after sending, make the button usable again.
  window.addEventListener('pageshow', function () {
    button.disabled = false;
    buttonLabel.textContent = defaultLabel;
  });
})();
